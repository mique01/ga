// Exportamos un objeto vacío solo para que el archivo sea válido
export const rechartsConfig = {}

