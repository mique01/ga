// Este archivo es solo un marcador de posición para las dependencias
// JSZip y FileSaver se cargarán dinámicamente en el componente

export {}

