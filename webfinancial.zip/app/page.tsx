"use client"

import { useState, useEffect } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import ExpenseTracker from "@/components/expense-tracker"
import CategoryManager from "@/components/category-manager"
import PaymentMethodManager from "@/components/payment-method-manager"
import PeopleManager from "@/components/people-manager"
import ExpenseDashboard from "@/components/expense-dashboard"
import AppSettings from "@/components/app-settings"
import ReceiptManager from "@/components/receipt-manager"

export default function Home() {
  const [livingStatus, setLivingStatus] = useState<"solo" | "acompañado">("solo")
  const [isLoaded, setIsLoaded] = useState(false)

  // Cargar configuración desde localStorage
  useEffect(() => {
    if (typeof window !== "undefined") {
      const savedSettings = localStorage.getItem("appSettings")

      if (savedSettings) {
        try {
          const settings = JSON.parse(savedSettings)
          if (settings.livingStatus) {
            setLivingStatus(settings.livingStatus)
          }
        } catch (error) {
          console.error("Error parsing settings:", error)
        }
      }

      setIsLoaded(true)
    }
  }, [])

  // Escuchar cambios en la configuración
  useEffect(() => {
    if (typeof window !== "undefined") {
      const handleStorageChange = () => {
        const savedSettings = localStorage.getItem("appSettings")

        if (savedSettings) {
          try {
            const settings = JSON.parse(savedSettings)
            if (settings.livingStatus) {
              setLivingStatus(settings.livingStatus)
            }
          } catch (error) {
            console.error("Error parsing settings from storage event:", error)
          }
        }
      }

      window.addEventListener("storage", handleStorageChange)

      // También verificamos periódicamente por cambios en localStorage
      const interval = setInterval(() => {
        const savedSettings = localStorage.getItem("appSettings")

        if (savedSettings) {
          try {
            const settings = JSON.parse(savedSettings)
            if (settings.livingStatus !== livingStatus) {
              setLivingStatus(settings.livingStatus)
            }
          } catch (error) {
            console.error("Error parsing settings from interval:", error)
          }
        }
      }, 1000)

      return () => {
        window.removeEventListener("storage", handleStorageChange)
        clearInterval(interval)
      }
    }
  }, [livingStatus])

  if (!isLoaded) {
    return <div className="flex items-center justify-center min-h-screen">Cargando...</div>
  }

  return (
    <main className="container mx-auto p-4 max-w-5xl">
      <h1 className="text-3xl font-bold mb-6 text-center">Seguimiento Financiero</h1>

      <Tabs defaultValue="dashboard" className="w-full">
        <TabsList className="grid grid-cols-6 md:grid-cols-7 mb-8">
          <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
          <TabsTrigger value="expenses">Gastos</TabsTrigger>
          <TabsTrigger value="categories">Categorías</TabsTrigger>
          <TabsTrigger value="payment-methods">Métodos</TabsTrigger>
          {livingStatus === "acompañado" && <TabsTrigger value="people">Personas</TabsTrigger>}
          <TabsTrigger value="receipts">Comprobantes</TabsTrigger>
          <TabsTrigger value="settings">Configuración</TabsTrigger>
        </TabsList>

        <TabsContent value="dashboard" className="mt-0">
          <ExpenseDashboard />
        </TabsContent>

        <TabsContent value="expenses" className="mt-0">
          <ExpenseTracker />
        </TabsContent>

        <TabsContent value="categories" className="mt-0">
          <CategoryManager />
        </TabsContent>

        <TabsContent value="payment-methods" className="mt-0">
          <PaymentMethodManager />
        </TabsContent>

        {livingStatus === "acompañado" && (
          <TabsContent value="people" className="mt-0">
            <PeopleManager />
          </TabsContent>
        )}

        <TabsContent value="receipts" className="mt-0">
          <ReceiptManager />
        </TabsContent>

        <TabsContent value="settings" className="mt-0">
          <AppSettings />
        </TabsContent>
      </Tabs>
    </main>
  )
}

